Author: Julian Torres
Course: CS-344
Assignment: Program-2

To compile the code:
    make

To run the program:
    Method 1:
        make run

    Method 2:
        ./movies_by_year

To check for memory leaks:
    Method 1:
        make check

    Method 2:
        valgrind --leak-check=yes ./movies_by_year
