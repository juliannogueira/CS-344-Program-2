#include <stdio.h>

#include "util.h"
#include "movie.h"
#include "menu.h"

/*
 * Run the menu to process movie data files.
 */
int main(void) {
    runMenu();

    return 0;
}